#!/bin/bash

RAIZ=`dirname $0`
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$RAIZ/bin/release:$PATH

$RAIZ/bin/release/Tonatiuh